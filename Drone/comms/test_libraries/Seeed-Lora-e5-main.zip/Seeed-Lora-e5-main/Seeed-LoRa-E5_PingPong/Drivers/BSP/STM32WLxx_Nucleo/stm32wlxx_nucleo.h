/*
 * stm32wlxx_nucleo.h
 *
 *  Created on: Mar 18, 2022
 *      Author: Dana H. Myers
 */

#ifndef BSP_STM32WLXX_NUCLEO_STM32WLXX_NUCLEO_H_
#define BSP_STM32WLXX_NUCLEO_STM32WLXX_NUCLEO_H_

/*
 * Dummy file - no BSP functions use for GPIO
 */


#endif /* BSP_STM32WLXX_NUCLEO_STM32WLXX_NUCLEO_H_ */
